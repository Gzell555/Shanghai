Shanghai on Foot - static website

Upload this whole folder (index.html, hsr.json, tiles/) to any static host:
- Netlify: app.netlify.com/drop, drag this folder in
- GitHub Pages: push the folder contents to a repo, Settings > Pages > deploy from branch
- Cloudflare Pages: Create project > Direct upload

It must be served over http(s); double-clicking index.html will not load the street tiles.
